#include <get_folder_stat.h>
#include <sys/syscall.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void printInfo(struct folder_info *info)
{
	printf("\tName: %s\n", info->name);
	printf("\tPermission: %o\n", info->permission);
	printf("\tUID: %d\n", info->uid);
	printf("\tGID: %d\n", info->gid);
	printf("\tSize: %lld (Bytes)\n", info->size);
	printf("\tTime: %ld\n", info->atime);
}

int main(int argc, char **argv)
{
	const char *path;
	if (argc >= 2)
	{
		path = argv[1];
		printf("Using path: %s\n", path);
	}
	else
	{
		puts("Using current directory");
		path = NULL;
	}
	struct folder_stat stat;
	get_folder_stat(path, &stat);
	printf("\nStudent ID: %ld\n", stat.studentID);
	printf("\nCurrent folder\n");
	printInfo(&stat.folder);
	printf("\nParent folder\n");
	printInfo(&stat.parent_folder);
	printf("\nLast access child folder\n");
	printInfo(&stat.last_access_child_folder);
	return 0;
}