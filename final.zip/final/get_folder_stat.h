#ifndef _GET_FOLDER_STAT_H_
#define _GET_FOLDER_STAT_H_

#include <stdlib.h>
#include <unistd.h>

//******************************* [STRUCT FOLDER] ****************************/ /
struct folder_info
{					   //info about a single folder
	char name[128];	   //name of the current folder
	mode_t permission; // permission mode
	uid_t uid;
	gid_t gid;
	long long int size;
	time_t atime;
};
struct folder_stat
{ // Statistic about current folder
	long studentID;
	struct folder_info folder;					 // Current folder
	struct folder_info parent_folder;			 // Parent folder
	struct folder_info last_access_child_folder; //Last access child folder
};
//*************************************************************************//

long get_folder_stat(const char *path, struct folder_stat *info);
#endif