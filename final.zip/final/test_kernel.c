#include <sys/syscall.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

struct folder_info
{ //info about a single folder
	char name[128];
	mode_t permission;
	uid_t uid;
	gid_t gid;
	long long int size; // in Bytes
	time_t atime;
};

struct folder_stat
{ //Statistic about current folder
	long studentID;
	struct folder_info folder;
	struct folder_info parent_folder;
	struct folder_info last_access_child_folder;
};

void printInfo(struct folder_info *info)
{
	printf("\tName: %s\n", info->name);
	printf("\tPermission: %o\n", info->permission);
	printf("\tUID: %d\n", info->uid);
	printf("\tGID: %d\n", info->gid);
	printf("\tSize: %lld (Bytes)\n", info->size);
	printf("\tTime: %ld\n", info->atime);
}

int main(int argc, char **argv)
{
	const char *path;
	if (argc >= 2)
	{
		path = argv[1];
		printf("Using path: %s\n", path);
	}
	else
	{
		puts("Using current directory");
		path = NULL;
	}
	struct folder_stat stat;
	syscall(548, path, &stat);
	printf("\nStudent ID: %ld\n", stat.studentID);
	printf("\nCurrent folder\n");
	printInfo(&stat.folder);
	printf("\nParent folder\n");
	printInfo(&stat.parent_folder);
	printf("\nLast access child folder\n");
	printInfo(&stat.last_access_child_folder);
	return 0;
}