#include "get_folder_stat.h"
#include <sys/syscall.h>
#include <linux/kernel.h>
#include <stdlib.h>

#include <unistd.h>

long get_folder_stat(const char *path, struct folder_stat *info)
{
	long val;
	val = syscall(548, path, info);
	return val;
}