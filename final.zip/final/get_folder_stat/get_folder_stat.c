#include <linux/fs.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/buffer_head.h>
#include <linux/dcache.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/string.h>
#include <linux/syscalls.h>
#include <asm/uaccess.h>
#include <asm/segment.h>

//*************************** [QUEUE] *****************************//
struct Node
{
	char *text;
	struct Node *next;
};

struct Queue
{
	struct Node *head;
	struct Node *tail;
	int size;
};

void init_queue(struct Queue *q) //init queue
{
	q->head = NULL;
	q->tail = NULL;
	q->size = 0;
}

void add_node(struct Queue *q, const char *pass_text) // add pass_text to end of queue
{
	struct Node *node = (struct Node *)kmalloc(sizeof(struct Node), GFP_USER);
	node->text = (char *)kmalloc(sizeof(char) * strlen(pass_text) + 1, GFP_USER);
	strcpy(node->text, pass_text);
	node->next = NULL;

	if (q->size == 0)
	{
		q->head = q->tail = node;
	}
	else
	{
		q->tail->next = node;
		q->tail = node;
	}
	q->size += 1;
}

char *get_front(struct Queue *q)
{
	return q->head->text;
}

void pop_front(struct Queue *q) // pop front node of queue
{
	if (q->size > 0)
	{
		struct Node *node = q->head;
		q->head = q->head->next;
		if (q->head == NULL)
			q->tail = NULL;
		kfree(node->text);
		kfree(node);
		q->size -= 1;
	}
}
//****************************************************************//

//******************************* [STRUCT FOLDER] ****************************//
struct folder_info
{					   //info about a single folder
	char name[128];	   //name of the current folder
	mode_t permission; // permission mode
	uid_t uid;
	gid_t gid;
	long long int size;
	time_t atime;
};
struct folder_stat
{ // Statistic about current folder
	long studentID;
	struct folder_info folder;					 // Current folder
	struct folder_info parent_folder;			 // Parent folder
	struct folder_info last_access_child_folder; //Last access child folder
};
//*************************************************************************//

//*********** [GLOBAL VARIABLE] **************//
static const char *curr_path;
static long long int total_size;
static struct Queue *child_queue;
static char *last_acess_child_path;
static int init;
//*******************************************//

//******************* [GET DIRECTORY INFOMATION] **********************//
void getDirInfo(struct folder_info *fold, struct dentry *den)
{
	strcpy(fold->name, den->d_name.name);
	fold->permission = den->d_inode->i_mode;
	fold->uid = den->d_inode->i_uid.val;
	fold->gid = den->d_inode->i_gid.val;
	fold->atime = den->d_inode->i_atime.tv_sec;
};
//*********************************************************************//

//************************************* [GET SIZE] ***********************************//
//-Global variable for both--------------------------
char *temp_path;
//---------------------------------------------------
static int processOnPerChild(struct dir_context *ctx, const char *child_name, int child_name_len, loff_t offset, u64 ino, unsigned int child_type)
{
	char *child_path;

	struct kstat s;
	int error;
	mm_segment_t old_fs;

	if (strcmp(child_name, ".") == 0 || strcmp(child_name, "..") == 0)
		return 0;

	//-Get full child path----------------------
	child_path = (char *)kmalloc((strlen(temp_path) + child_name_len + 2), GFP_USER);
	strcpy(child_path, temp_path);
	strcat(child_path, "/");
	strcat(child_path, child_name);
	//------------------------------------------

	//-Add directory into queue-------------------
	if (child_type == DT_DIR)
	{
		add_node(child_queue, child_path);
	}
	else
	{
		//-Plus the size of child files------
		old_fs = get_fs();
		set_fs(KERNEL_DS);
		error = vfs_lstat(child_path, &s);
		if (!error)
			total_size += s.size;
		set_fs(old_fs);
	}

	kfree(child_path);
	return 0;
}

long long int getSize(const char *path)
{
	struct Queue Q;
	child_queue = &Q;

	init_queue(child_queue);
	add_node(child_queue, path);
	total_size = 0;
	while (child_queue->size)
	{
		temp_path = (char *)kmalloc((strlen(get_front(child_queue)) + 1), GFP_USER);
		strcpy(temp_path, get_front(child_queue));
		struct file *f = filp_open(temp_path, O_RDONLY | O_NOFOLLOW | O_NOATIME, 0);
		if (!IS_ERR(f))
		{
			total_size += f->f_path.dentry->d_inode->i_size; // Plus the size of directory
			struct dir_context ctx = {.actor = &processOnPerChild};
			iterate_dir(f, &ctx);
		}
		pop_front(child_queue);
		kfree(temp_path);
		filp_close(f, 0);
	}
	return total_size;
}
//***********************************************************************//

//************************ [FIND LAST ACCESS CHILD] *************************//
bool compare_time(char *a, char *b)
{
	bool check;

	struct file *f1 = filp_open(a, O_RDONLY | O_NOFOLLOW | O_NOATIME, 0);
	struct file *f2 = filp_open(b, O_RDONLY | O_NOFOLLOW | O_NOATIME, 0);

	if ((!IS_ERR(f1)) && (!IS_ERR(f2)))
		check = f1->f_path.dentry->d_inode->i_atime.tv_sec > f2->f_path.dentry->d_inode->i_atime.tv_sec;

	filp_close(f1, 0);
	filp_close(f2, 0);

	return check;
}
static int process(struct dir_context *ctx, const char *child_name, int child_name_len, loff_t offset, u64 ino, unsigned int child_type)
{
	char *child_path;

	if (strcmp(child_name, ".") == 0 || strcmp(child_name, "..") == 0)
		return 0;

	//-Get full child path----------------------
	child_path = (char *)kmalloc((strlen(curr_path) + child_name_len + 2), GFP_USER);
	strcpy(child_path, curr_path);
	strcat(child_path, "/");
	strcat(child_path, child_name);
	//------------------------------------------

	//-Get last access child folder----------------
	if (child_type == DT_DIR)
	{
		if (init == 0)
		{
			last_acess_child_path = (char *)kmalloc((strlen(child_path) + 1), GFP_USER);
			strcpy(last_acess_child_path, child_path);
			init = 1;
		}
		else
		{
			if (compare_time(child_path, last_acess_child_path))
			{
				kfree(last_acess_child_path);
				last_acess_child_path = (char *)kmalloc((strlen(child_path) + 1), GFP_USER);
				strcpy(last_acess_child_path, child_path);
			}
		}
	}
	//--------------------------------------

	kfree(child_path);
	return 0;
}
//***************************************************************************//

//*************** [PRINT] ************************//
void printFolder(struct folder_info *fold)
{
	printk("Name: %s", fold->name);
	printk("Permission: %o", fold->permission);
	printk("UID: %d", fold->uid);
	printk("GID: %d", fold->gid);
	printk("Size: %lld (Bytes)", fold->size);
	printk("Time: %ld", fold->atime);
}
static void printAll(struct folder_stat *stat)
{
	printk("Student ID: %ld", stat->studentID);
	printk("Current folder");
	printFolder(&stat->folder);
	printk("Parent folder");
	printFolder(&stat->parent_folder);
	printk("Last access child folder");
	printFolder(&stat->last_access_child_folder);
}
//**************************************************//

SYSCALL_DEFINE2(get_folder_stat, const char *, path, struct folder_stat *, stat)
{
	//-Variable-------------
	char *parent_path;
	struct dentry *den; // Info of current folder

	struct file *f;
	struct file *child;
	struct file *parent;

	//-Student ID---------------------
	stat->studentID = 1914637;
	//--------------------------------

	//-Process path--------------
	if (path == NULL)
		curr_path = ".";
	else
		curr_path = path;

	//-Parent path--------------------------------
	parent_path = (char *)kmalloc(strlen(curr_path) + 10, GFP_USER);
	strcpy(parent_path, curr_path);
	strcat(parent_path, "/..");

	//-Get info of current folder-------------
	f = filp_open(curr_path, O_NOATIME | O_RDONLY, 0); //O_NOATIME means don't change last access time, O_RDONLY means read only
	if (IS_ERR(f))
		return EINVAL;
	den = f->f_path.dentry;
	getDirInfo(&stat->folder, den);

	//-Last access child-------------
	init = 0;
	struct dir_context ctx = {.actor = &process};
	iterate_dir(f, &ctx);
	child = filp_open(last_acess_child_path, O_NOATIME | O_RDONLY, 0);
	if (IS_ERR(child))
		return EINVAL;
	den = child->f_path.dentry;
	getDirInfo(&stat->last_access_child_folder, den);
	//-close-------------
	filp_close(child, 0);
	filp_close(f, 0);

	//-Get info of parent folder-------------
	parent = filp_open(parent_path, O_NOATIME | O_RDONLY, 0);
	if (IS_ERR(parent))
		return EINVAL;
	den = parent->f_path.dentry;
	getDirInfo(&stat->parent_folder, den);
	filp_close(parent, 0);

	//-Get size--------------------------------
	stat->folder.size = getSize(curr_path);
	stat->parent_folder.size = getSize(parent_path);
	stat->last_access_child_folder.size = getSize(last_acess_child_path);

	kfree(parent_path);
	kfree(last_acess_child_path);

	printAll(stat);
	return 0;
}
